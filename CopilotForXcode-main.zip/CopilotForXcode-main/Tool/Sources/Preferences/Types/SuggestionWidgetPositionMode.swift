public enum SuggestionWidgetPositionMode: Int, CaseIterable {
    case fixedToBottom = 0
    case alignToTextCursor = 1
}
